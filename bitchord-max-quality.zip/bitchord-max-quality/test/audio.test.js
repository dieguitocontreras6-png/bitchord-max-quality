import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync, spawnSync } from 'node:child_process';
import { mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { parseFlac, parseWav, parseMp3, parseOgg, sniffAudio, describe, tierOf } from '../src/audio.js';
import { makeFlac, makeWav, makeMp3, makeOpus, makeHtml } from './helpers/fixtures.js';

test('FLAC STREAMINFO: 16 bit / 44.1 kHz', () => {
  const i = parseFlac(makeFlac({ sampleRate: 44100, bitDepth: 16, totalSamples: 44100 * 100 }));
  assert.deepEqual([i.codec, i.lossless, i.bitDepth, i.sampleRate, i.channels, Math.round(i.durationSec)], ['flac', true, 16, 44100, 2, 100]);
});

test('FLAC STREAMINFO: 24 bit / 96 kHz y 24 bit / 192 kHz', () => {
  assert.equal(parseFlac(makeFlac({ sampleRate: 96000, bitDepth: 24 })).bitDepth, 24);
  const i = parseFlac(makeFlac({ sampleRate: 192000, bitDepth: 24, totalSamples: 192000 * 60 * 5 }));
  assert.equal(i.sampleRate, 192000);
  assert.equal(Math.round(i.durationSec), 300);
});

test('FLAC con etiqueta ID3v2 delante se detecta igualmente', () => {
  const i = sniffAudio(makeFlac({ bitDepth: 24, sampleRate: 48000, id3: 2000 }));
  assert.equal(i.bitDepth, 24);
});

test('Datos que no son audio devuelven null (HTML, basura, truncado)', () => {
  assert.equal(sniffAudio(makeHtml()), null);
  assert.equal(parseFlac(Buffer.from('fLaC')), null);
  assert.equal(parseFlac(Buffer.alloc(100)), null);
});

test('WAV PCM 16 y 24 bit (incluido WAVE_FORMAT_EXTENSIBLE) y float', () => {
  const a = parseWav(makeWav({ bits: 16 }));
  assert.deepEqual([a.lossless, a.bitDepth, a.sampleRate, Math.round(a.durationSec)], [true, 16, 44100, 10]);
  const b = parseWav(makeWav({ bits: 24, sampleRate: 96000, extensible: true }));
  assert.deepEqual([b.lossless, b.bitDepth, b.sampleRate], [true, 24, 96000]);
  assert.equal(parseWav(makeWav({ bits: 32, tag: 3 })).float, true);
});

test('WAV con códec con pérdida (MP3 dentro de WAV) NO es sin pérdida', () => {
  const i = parseWav(makeWav({ bits: 16, tag: 0x55 }));
  assert.equal(i.lossless, false);
});

test('MP3 CBR 128/320 kbps y VBR (Xing)', () => {
  assert.equal(parseMp3(makeMp3({ brIdx: 9 })).bitrate, 128000);
  assert.equal(parseMp3(makeMp3({ brIdx: 14 })).bitrate, 320000);
  const v = parseMp3(makeMp3({ vbr: true }));
  assert.equal(v.vbr, true); assert.equal(v.bitrate, null);
});

test('MP3 con ID3 mayor que la ventana pide leer más bytes', () => {
  const buf = makeMp3({ id3: 70000, size: 70000 + 5000 }).subarray(0, 65536);
  const r = sniffAudio(buf);
  assert.equal(r.incomplete, true);
  assert.equal(r.nextOffset, 70010);
});

test('Ogg Opus se identifica como con pérdida', () => {
  const i = parseOgg(makeOpus());
  assert.deepEqual([i.codec, i.lossless], ['opus', false]);
});

test('Etiquetas honestas y niveles', () => {
  assert.equal(describe(parseFlac(makeFlac({ bitDepth: 24, sampleRate: 96000 }))), 'Lossless · 24-bit / 96 kHz (FLAC)');
  assert.equal(describe(parseFlac(makeFlac({ bitDepth: 16, sampleRate: 44100 }))), 'Lossless · 16-bit / 44.1 kHz (FLAC)');
  assert.equal(describe(parseMp3(makeMp3({ brIdx: 11 }))), 'MP3 · 192 kbps (lossy)');
  assert.equal(tierOf(parseMp3(makeMp3({ brIdx: 9 }))), 'LOW');
  assert.equal(tierOf(parseMp3(makeMp3({ brIdx: 14 }))), 'HIGH');
});

// --- Archivos reales generados con ffmpeg (se omiten si ffmpeg/códecs no están disponibles) ---
const hasFfmpeg = spawnSync('ffmpeg', ['-version']).status === 0;
const dir = hasFfmpeg ? mkdtempSync(path.join(tmpdir(), 'bcmq-')) : null;
function gen(name, args) {
  const out = path.join(dir, name);
  const r = spawnSync('ffmpeg', ['-y', '-v', 'error', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=2:sample_rate=' + (args.sr || 44100), ...args.a, out]);
  return r.status === 0 ? readFileSync(out) : null;
}

test('ffmpeg real: FLAC 16-bit y FLAC 24-bit coinciden con lo que se lee', { skip: !hasFfmpeg }, () => {
  const f16 = gen('a16.flac', { a: ['-c:a', 'flac', '-sample_fmt', 's16'] });
  const f24 = gen('a24.flac', { sr: 96000, a: ['-c:a', 'flac', '-sample_fmt', 's32', '-bits_per_raw_sample', '24'] });
  const i16 = sniffAudio(f16), i24 = sniffAudio(f24);
  assert.deepEqual([i16.bitDepth, i16.sampleRate], [16, 44100]);
  assert.deepEqual([i24.bitDepth, i24.sampleRate], [24, 96000]);
  assert.ok(Math.abs(i24.durationSec - 2) < 0.01);
});

test('ffmpeg real: WAV 24-bit, MP3 y Opus', { skip: !hasFfmpeg }, (t) => {
  const wav = gen('a.wav', { a: ['-c:a', 'pcm_s24le'] });
  assert.equal(sniffAudio(wav).bitDepth, 24);
  const mp3 = gen('a.mp3', { a: ['-c:a', 'libmp3lame', '-b:a', '192k'] });
  if (mp3) { const i = sniffAudio(mp3); assert.equal(i.lossless, false); assert.equal(i.codec, 'mp3'); }
  else t.diagnostic('libmp3lame no disponible: MP3 omitido');
  const opus = gen('a.opus', { a: ['-c:a', 'libopus', '-b:a', '96k'] });
  if (opus) assert.equal(sniffAudio(opus).codec, 'opus');
  else t.diagnostic('libopus no disponible: Opus omitido');
});

test('ffmpeg real: un MP3 convertido a FLAC sigue siendo FLAC válido (la cabecera no delata el origen)', { skip: !hasFfmpeg }, (t) => {
  // Documenta una limitación: STREAMINFO no puede probar que el audio no venga de un códec con pérdida.
  const mp3 = gen('t.mp3', { a: ['-c:a', 'libmp3lame', '-b:a', '128k'] });
  if (!mp3) return t.skip('libmp3lame no disponible');
  const p = path.join(dir, 't.mp3'), o = path.join(dir, 't_from_mp3.flac');
  execFileSync('ffmpeg', ['-y', '-v', 'error', '-i', p, '-c:a', 'flac', o]);
  const i = sniffAudio(readFileSync(o));
  assert.equal(i.codec, 'flac'); // por eso el adaptador marca suspectTranscode cuando la fuente declara un origen con pérdida
});
