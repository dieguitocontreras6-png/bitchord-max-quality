// Pruebas SIMULADAS de extremo a extremo: addon real (HTTP) -> adaptadores reales -> servidores locales falsos.
// No tocan Internet. Las pruebas contra servicios reales están en test/integration/.
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../src/config.js';
import { createApp } from '../src/server.js';
import { decodeRefs } from '../src/ids.js';
import { startMock } from './helpers/mock.js';
import { makeFlac, makeMp3, makeHtml } from './helpers/fixtures.js';

const ART = 'Example Artist';
const iaFile = (name, extra = {}) => ({ name, source: 'original', format: 'Flac', artist: ART, ...extra });
const state = {
  iaDocs: [
    { identifier: 'night-drive', title: 'Night Drive', creator: ART, downloads: 100 },
    { identifier: 'other-band', title: 'Greatest Hits', creator: 'Other Band', downloads: 5000 },
  ],
  iaMeta: {
    'night-drive': {
      metadata: { identifier: 'night-drive', title: 'Night Drive', creator: ART, licenseurl: 'https://creativecommons.org/licenses/by/4.0/' },
      files: [
        iaFile('01 Midnight Signal.flac', { title: 'Midnight Signal', length: '242.5' }),
        { name: '01 Midnight Signal.mp3', source: 'derivative', format: 'VBR MP3', original: '01 Midnight Signal.flac', length: '242.5' },
        iaFile('02 Fake Lossless.flac', { title: 'Fake Lossless', length: '200' }),
        iaFile('03 Broken Link.flac', { title: 'Broken Link' }),
        iaFile('04 Expired Url.flac', { title: 'Expired Url' }),
        iaFile('05 Html Page.flac', { title: 'Html Page' }),
        iaFile('06 Flaky Server.flac', { title: 'Flaky Server' }),
        iaFile('07 Overclaim.flac', { title: 'Overclaim', format: '24bit Flac' }),
        iaFile('08 Slow Server.flac', { title: 'Slow Server' }),
        iaFile('09 Suspect Origin.flac', { title: 'Suspect Origin', source: 'derivative', original: '09 Suspect Origin.mp3' }),
        { name: '09 Suspect Origin.mp3', source: 'original', format: 'VBR MP3', title: 'Suspect Origin' },
      ],
    },
    'other-band': {
      metadata: { identifier: 'other-band', title: 'Greatest Hits', creator: 'Other Band' },
      files: [{ name: 'a.flac', source: 'original', format: 'Flac', title: 'Midnight Signal', artist: 'Other Band' }],
    },
  },
  files: {
    '01 Midnight Signal.flac': { buf: makeFlac({ bitDepth: 16, sampleRate: 44100, totalSamples: 44100 * 242, size: 150000 }) },
    '01 Midnight Signal.mp3': { buf: makeMp3({ vbr: true }), type: 'audio/mpeg' },
    '02 Fake Lossless.flac': { buf: makeMp3({ brIdx: 11 }), type: 'audio/flac' }, // etiquetado FLAC, en realidad MP3
    '03 Broken Link.flac': { status: 404 },
    '04 Expired Url.flac': { status: 410 },
    '05 Html Page.flac': { buf: makeHtml(), type: 'text/html' },
    '06 Flaky Server.flac': { status: 503 },
    '07 Overclaim.flac': { buf: makeFlac({ bitDepth: 16, sampleRate: 44100 }) }, // dice 24 bit, es 16
    '08 Slow Server.flac': { hang: true },
    '09 Suspect Origin.flac': { buf: makeFlac({ bitDepth: 16, sampleRate: 44100 }) },
    '09 Suspect Origin.mp3': { buf: makeMp3({ brIdx: 14 }), type: 'audio/mpeg' },
    'jm/555.flac': { buf: makeFlac({ bitDepth: 24, sampleRate: 96000, totalSamples: 96000 * 243, size: 400000 }) },
    'jm/555.mp3': { buf: makeMp3({ brIdx: 14 }), type: 'audio/mpeg' },
  },
  commonsPages: [
    { title: 'File:Midnight Signal (cover).ogg', imageinfo: [{ url: 'x', extmetadata: { Artist: { value: '<a>Random Person</a>' }, LicenseShortName: { value: 'CC BY-SA 4.0' } } }] },
    { title: 'File:Rain on window.ogg', imageinfo: [{ url: 'y', extmetadata: {} }] },
  ],
  jmSearch: [{ id: '555', name: 'Midnight Signal', artist_name: ART, album_name: 'Night Drive', duration: 243, image: 'https://img/555.jpg', license_ccurl: 'http://creativecommons.org/licenses/by/3.0/' }],
  jmTracks: {},
};

let mock, app, base;
const get = async (p) => { const r = await fetch(base + p); return { status: r.status, headers: r.headers, body: await r.json().catch(() => null) }; };
const search = (q) => get(`/search?q=${encodeURIComponent(q)}&quality=lossless`);
const streamOf = async (q, quality = 'LOSSLESS') => {
  const s = await search(q);
  assert.ok(s.body.tracks.length >= 1, `sin resultados para "${q}"`);
  return get(`/stream/${s.body.tracks[0].id}?quality=${quality}`);
};

before(async () => {
  state.jmTracks['555'] = {};
  mock = await startMock(state);
  state.jmTracks['555'] = { flac: `${mock.base}/jm/555.flac`, mp32: `${mock.base}/jm/555.mp3` };
  state.files['09 Suspect Origin.mp3'].buf = makeMp3({ brIdx: 14 });
  const cfg = loadConfig({}, {
    jamendoClientId: 'test-client', bases: { ia: mock.base, commons: mock.base, jamendo: `${mock.base}/v3.0` },
    minIntervalMs: { default: 0 }, httpRetries: 0, httpTimeoutMs: 1500, probeTimeoutMs: 1200, searchDeadlineMs: 3000, streamDeadlineMs: 8000, logLevel: 'silent', rateLimitPerMin: 1000,
  });
  app = createApp({ cfg });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${app.server.address().port}`;
});
after(async () => { await new Promise((r) => { app.server.closeAllConnections?.(); app.server.close(r); }); await mock.close(); });

test('manifest sigue el contrato (id, resources, switches numéricos)', async () => {
  const m = (await get('/manifest.json')).body;
  assert.equal(typeof m.id, 'string'); assert.ok(m.id);
  assert.deepEqual(m.resources, ['search', 'stream']);
  assert.equal(m.allowDownloads, 0); assert.equal(m.checkValidLossless, 0);
});

test('búsqueda: devuelve la canción correcta una sola vez (IA + Jamendo deduplicados) y descarta artistas incorrectos', async () => {
  const r = await search('Midnight Signal Example Artist');
  assert.equal(r.status, 200);
  assert.equal(r.body.tracks.length, 1);
  const t = r.body.tracks[0];
  assert.equal(t.title, 'Midnight Signal'); assert.equal(t.artist, ART); assert.equal(t.audioQuality, 'LOSSLESS');
  assert.ok(typeof t.id === 'string' && t.id.length);
  const refs = decodeRefs(t.id, ['ia', 'cm', 'jm']);
  assert.deepEqual(refs.map((x) => x[0]).sort(), ['ia', 'jm']); // las dos fuentes con la misma grabación
  assert.ok(!JSON.stringify(r.body).includes('Other Band'));
  assert.ok(!JSON.stringify(r.body).includes('Random Person'));
});

test('búsqueda: sin coincidencias reales => lista vacía (nada inventado)', async () => {
  assert.deepEqual((await search('zzzz qqqq xxxx')).body, { tracks: [] });
  assert.deepEqual((await search('')).body, { tracks: [] });
  assert.deepEqual((await search('Midnight Signal Wrong Artist')).body, { tracks: [] });
});

test('búsqueda: IA se consulta con filtro de colecciones y mediatype:audio', () => {
  const q = mock.requests.find((r) => r.path === '/advancedsearch.php').q.q;
  assert.match(q, /mediatype:audio/); assert.match(q, /collection:\(etree OR netlabels/);
});

test('stream LOSSLESS: entre FLAC 16/44.1 (IA) y FLAC 24/96 (Jamendo) elige el 24 bit verificado', async () => {
  const r = await streamOf('Midnight Signal Example Artist', 'LOSSLESS');
  assert.equal(r.status, 200);
  assert.equal(r.body.bitDepth, 24); assert.equal(r.body.sampleRate, 96000);
  assert.equal(r.body.codec, 'flac'); assert.equal(r.body.manifest, 'none'); assert.equal(r.body.encrypted, false);
  assert.equal(r.body.quality, 'Lossless · 24-bit / 96 kHz (FLAC)');
  assert.match(r.body.url, /jm\/555\.flac/);
  assert.equal(r.body.bitrate, Math.round((400000 * 8) / 243)); // media real = tamaño*8/duración del fixture
});

test('stream HIGH y LOW: mejor lossy y lossy compacto, etiquetados como con pérdida', async () => {
  const hi = await streamOf('Midnight Signal Example Artist', 'HIGH');
  assert.equal(hi.body.codec, 'mp3'); assert.equal(hi.body.bitrate, 320000); assert.match(hi.body.quality, /lossy/);
  assert.equal(hi.body.bitDepth, undefined);
  const lo = await streamOf('Midnight Signal Example Artist', 'LOW');
  assert.equal(lo.body.codec, 'mp3'); assert.match(lo.body.quality, /lossy/);
});

test('archivo mal etiquetado: .flac que en realidad es MP3 se reporta como MP3 con pérdida', async () => {
  const r = await streamOf('Fake Lossless Example Artist');
  assert.equal(r.status, 200);
  assert.equal(r.body.codec, 'mp3'); assert.equal(r.body.bitrate, 192000); assert.match(r.body.quality, /MP3 · 192 kbps \(lossy\)/);
  assert.equal(r.body.bitDepth, undefined);
});

test('etiqueta "24bit Flac" sin respaldo: se informa 16 bit (lo real)', async () => {
  const r = await streamOf('Overclaim Example Artist');
  assert.equal(r.body.bitDepth, 16); assert.equal(r.body.quality, 'Lossless · 16-bit / 44.1 kHz (FLAC)');
});

test('origen con pérdida declarado (FLAC derivado de MP3): no se presenta como lossless; se sirve el MP3 original', async () => {
  const r = await streamOf('Suspect Origin Example Artist');
  assert.equal(r.status, 200);
  assert.equal(r.body.codec, 'mp3'); assert.equal(r.body.bitrate, 320000); assert.match(r.body.quality, /lossy/);
});

test('URL rota (404) o caducada (410) o HTML disfrazado: 404 limpio, no se presenta como disponible', async () => {
  for (const q of ['Broken Link Example Artist', 'Expired Url Example Artist', 'Html Page Example Artist']) {
    const r = await streamOf(q);
    assert.equal(r.status, 404, q);
    assert.ok(r.body.error);
  }
});

test('fuente caída (503) o lenta (timeout): 503 con Retry-After, no 404', async () => {
  const a = await streamOf('Flaky Server Example Artist');
  assert.equal(a.status, 503); assert.equal(a.headers.get('retry-after'), '30');
  const b = await streamOf('Slow Server Example Artist');
  assert.equal(b.status, 503);
});

test('id inválido o manipulado: 404; método no permitido: 405', async () => {
  assert.equal((await get('/stream/%%%')).status, 404);
  assert.equal((await get('/stream/' + Buffer.from('[["zz","a"]]').toString('base64url'))).status, 404);
  const r = await fetch(base + '/search?q=a', { method: 'POST' });
  assert.equal(r.status, 405);
});

test('límite de peticiones entrante: 429 con Retry-After', async () => {
  const cfg = loadConfig({}, { sources: [], rateLimitPerMin: 3, logLevel: 'silent' });
  const a = createApp({ cfg });
  await new Promise((r) => a.server.listen(0, '127.0.0.1', r));
  const b = `http://127.0.0.1:${a.server.address().port}`;
  const codes = [];
  for (let i = 0; i < 5; i++) { const r = await fetch(`${b}/search?q=x`); codes.push(r.status); if (r.status === 429) assert.ok(r.headers.get('retry-after')); }
  assert.deepEqual(codes, [200, 200, 200, 429, 429]);
  await new Promise((r) => { a.server.closeAllConnections?.(); a.server.close(r); });
});
