// Constructores de cabeceras de audio sintéticas (solo para pruebas simuladas).
export function makeId3(payloadSize) {
  const h = Buffer.alloc(10);
  h.write('ID3', 0, 'latin1'); h[3] = 4;
  h[6] = (payloadSize >> 21) & 0x7f; h[7] = (payloadSize >> 14) & 0x7f; h[8] = (payloadSize >> 7) & 0x7f; h[9] = payloadSize & 0x7f;
  return Buffer.concat([h, Buffer.alloc(payloadSize)]);
}

export function makeFlac({ sampleRate = 44100, bitDepth = 16, channels = 2, totalSamples = 44100 * 30, size = 200000, id3 = 0 } = {}) {
  const si = Buffer.alloc(34);
  si.writeUInt16BE(4096, 0); si.writeUInt16BE(4096, 2);
  const ch = channels - 1, bps = bitDepth - 1, t = BigInt(totalSamples);
  si[10] = sampleRate >> 12; si[11] = (sampleRate >> 4) & 0xff;
  si[12] = ((sampleRate & 0xf) << 4) | (ch << 1) | (bps >> 4);
  si[13] = ((bps & 0xf) << 4) | Number((t >> 32n) & 0xfn);
  si.writeUInt32BE(Number(t & 0xffffffffn), 14);
  const head = Buffer.concat([Buffer.from('fLaC'), Buffer.from([0x80, 0, 0, 34]), si]);
  const pre = id3 ? makeId3(id3) : Buffer.alloc(0);
  return Buffer.concat([pre, head, Buffer.alloc(Math.max(0, size - head.length - pre.length), 0x55)]);
}

export function makeWav({ sampleRate = 44100, bits = 16, channels = 2, seconds = 10, tag = 1, extensible = false } = {}) {
  const blockAlign = channels * (bits / 8), dataSize = Math.round(sampleRate * seconds) * blockAlign;
  const fmtLen = extensible ? 40 : 16;
  const b = Buffer.alloc(12 + 8 + fmtLen + 8);
  b.write('RIFF', 0, 'latin1'); b.writeUInt32LE(b.length - 8 + dataSize, 4); b.write('WAVE', 8, 'latin1');
  b.write('fmt ', 12, 'latin1'); b.writeUInt32LE(fmtLen, 16);
  b.writeUInt16LE(extensible ? 0xfffe : tag, 20); b.writeUInt16LE(channels, 22); b.writeUInt32LE(sampleRate, 24);
  b.writeUInt32LE(sampleRate * blockAlign, 28); b.writeUInt16LE(blockAlign, 32); b.writeUInt16LE(bits, 34);
  if (extensible) { b.writeUInt16LE(22, 36); b.writeUInt16LE(bits, 38); b.writeUInt16LE(tag, 44); }
  const d = 20 + fmtLen;
  b.write('data', d, 'latin1'); b.writeUInt32LE(dataSize, d + 4);
  return Buffer.concat([b, Buffer.alloc(4096)]);
}

// Trama MPEG-1 Layer III. brIdx: 9=128k, 11=192k, 14=320k. vbr=true añade cabecera Xing.
export function makeMp3({ brIdx = 9, srIdx = 0, vbr = false, size = 100000, id3 = 0 } = {}) {
  const frame = Buffer.alloc(417 + 4);
  frame[0] = 0xff; frame[1] = 0xfb; frame[2] = (brIdx << 4) | (srIdx << 2); frame[3] = 0x00;
  if (vbr) frame.write('Xing', 4 + 32, 'latin1');
  const pre = id3 ? makeId3(id3) : Buffer.alloc(0);
  return Buffer.concat([pre, frame, Buffer.alloc(Math.max(0, size - frame.length - pre.length), 0x11)]);
}

export function makeOpus({ channels = 2, size = 50000 } = {}) {
  const payload = Buffer.alloc(19);
  payload.write('OpusHead', 0, 'latin1'); payload[8] = 1; payload[9] = channels; payload.writeUInt32LE(48000, 12);
  const page = Buffer.alloc(28); page.write('OggS', 0, 'latin1'); page[5] = 2; page[26] = 1; page[27] = 19;
  return Buffer.concat([page, payload, Buffer.alloc(Math.max(0, size - 47), 0x22)]);
}

export const makeHtml = () => Buffer.from('<!doctype html><html><body>Not found</body></html>');
