// Servidor HTTP local que imita Internet Archive, Wikimedia Commons y Jamendo (PRUEBAS SIMULADAS, no red real).
import http from 'node:http';

function serve(req, res, f) {
  if (f.hang) return; // nunca responde (prueba de timeout)
  if (f.status && f.status !== 200) { res.writeHead(f.status, { 'content-type': 'text/plain' }); return res.end('x'); }
  const buf = f.buf, type = f.type || 'audio/flac';
  const m = /bytes=(\d+)-(\d+)?/.exec(req.headers.range || '');
  if (m) {
    const a = Number(m[1]), b = Math.min(Number(m[2] ?? buf.length - 1), buf.length - 1);
    res.writeHead(206, { 'content-type': type, 'content-range': `bytes ${a}-${b}/${buf.length}`, 'content-length': b - a + 1, 'accept-ranges': 'bytes' });
    return res.end(buf.subarray(a, b + 1));
  }
  res.writeHead(200, { 'content-type': type, 'content-length': buf.length });
  res.end(buf);
}

export async function startMock(state) {
  const requests = [];
  const server = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://x');
    requests.push({ path: u.pathname, q: Object.fromEntries(u.searchParams) });
    const json = (o) => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
    let m;
    if (u.pathname === '/advancedsearch.php') return json({ response: { numFound: state.iaDocs.length, docs: state.iaDocs } });
    if ((m = /^\/metadata\/(.+)$/.exec(u.pathname))) return json(state.iaMeta[decodeURIComponent(m[1])] || {});
    if ((m = /^\/download\/([^/]+)\/(.+)$/.exec(u.pathname))) {
      const f = state.files[decodeURIComponent(m[2])];
      return f ? serve(req, res, f) : (res.writeHead(404), res.end());
    }
    if (u.pathname === '/w/api.php') return json({ query: { pages: state.commonsPages } });
    if (u.pathname === '/v3.0/tracks/') {
      const q = u.searchParams;
      if (q.get('search')) return json({ headers: { status: 'success' }, results: state.jmSearch });
      const fmt = q.get('audioformat');
      const t = state.jmTracks[q.get('id')];
      return json({ headers: { status: 'success' }, results: t && t[fmt] ? [{ id: q.get('id'), audio: t[fmt], license_ccurl: 'http://creativecommons.org/licenses/by/3.0/' }] : [] });
    }
    if ((m = /^\/jm\/(.+)$/.exec(u.pathname))) {
      const f = state.files[`jm/${m[1]}`];
      return f ? serve(req, res, f) : (res.writeHead(404), res.end());
    }
    res.writeHead(404); res.end();
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  return { base, requests, close: () => new Promise((r) => { server.closeAllConnections?.(); server.close(r); }) };
}
