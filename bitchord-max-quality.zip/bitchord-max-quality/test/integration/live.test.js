// PRUEBAS DE INTEGRACIÓN contra servicios REALES. Solo se ejecutan con RUN_INTEGRATION=1 y red disponible:
//   RUN_INTEGRATION=1 JAMENDO_CLIENT_ID=xxxx npm run test:integration
// No afirman resultados concretos (los catálogos cambian): comprueban que lo que el addon declara coincide
// con lo que un segundo sondeo independiente lee en el archivo real.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../../src/config.js';
import { createApp } from '../../src/server.js';
import { sniffAudio } from '../../src/audio.js';

const RUN = process.env.RUN_INTEGRATION === '1';
const QUERIES = (process.env.IT_QUERIES || 'Gymnopedie Satie|Bach Cello Suite|Beethoven Moonlight Sonata').split('|');
let app, base;

async function boot() {
  if (app) return;
  app = createApp({ cfg: loadConfig(process.env, { logLevel: 'warn' }) });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${app.server.address().port}`;
}
after(async () => { if (app) await new Promise((r) => { app.server.closeAllConnections?.(); app.server.close(r); }); });
const j = async (p) => { const r = await fetch(base + p); return { status: r.status, body: await r.json() }; };

test('live: manifest', { skip: !RUN }, async () => { await boot(); assert.ok((await j('/manifest.json')).body.id); });

for (const q of QUERIES) {
  test(`live: "${q}" -> lo declarado coincide con el archivo real`, { skip: !RUN }, async (t) => {
    await boot();
    const s = await j(`/search?q=${encodeURIComponent(q)}`);
    assert.equal(s.status, 200);
    if (!s.body.tracks.length) return t.skip('sin resultados reales para esta consulta (válido: no se inventan)');
    for (const track of s.body.tracks.slice(0, 3)) {
      const r = await j(`/stream/${track.id}?quality=LOSSLESS`);
      if (r.status !== 200) { t.diagnostic(`${track.title}: HTTP ${r.status}`); continue; }
      assert.match(r.body.url, /^https?:\/\//);
      const res = await fetch(r.body.url, { headers: { range: 'bytes=0-65535' } });
      assert.ok([200, 206].includes(res.status), `URL inaccesible: ${r.body.url}`);
      const info = sniffAudio(Buffer.from(await res.arrayBuffer()).subarray(0, 65536));
      assert.ok(info && !info.incomplete, 'el archivo no es audio reconocible');
      assert.equal(info.codec, r.body.codec);
      if (info.lossless) { assert.equal(info.bitDepth, r.body.bitDepth); assert.equal(info.sampleRate, r.body.sampleRate); }
      else assert.match(r.body.quality, /lossy/);
      t.diagnostic(`${track.title} → ${r.body.quality}`);
    }
  });
}
