import test from 'node:test';
import assert from 'node:assert/strict';
import { norm, cleanTitle, versionTags, parseQuery } from '../src/text.js';
import { scoreCandidate, groupCandidates } from '../src/match.js';
import { pickBest, normalizeTier } from '../src/select.js';
import { encodeRefs, decodeRefs } from '../src/ids.js';

const S = (q, c, extra) => scoreCandidate(parseQuery(q, extra), c);

test('normalización: acentos, mayúsculas, símbolos y espacios', () => {
  assert.equal(norm('  Beyoncé  &  JAY‑Z!! '), 'beyonce and jay z');
  assert.equal(norm('Sigur Rós – Hoppípolla'), 'sigur ros hoppipolla');
  assert.equal(cleanTitle('Yesterday (Remastered 2009)'), 'yesterday');
  assert.equal(cleanTitle('Hey Jude - 2015 Remaster'), 'hey jude');
});

test('detecta versiones alternativas', () => {
  assert.deepEqual([...versionTags('Song (Live at Wembley)')], ['live']);
  assert.deepEqual([...versionTags('Song - Karaoke Version')], ['karaoke']);
  assert.equal(versionTags('Song (Remastered 2011)').size, 0);
});

test('acepta título + artista en cualquier orden', () => {
  const c = { title: 'Yesterday', artist: 'The Beatles', album: 'Help!' };
  assert.equal(S('Yesterday The Beatles', c).accepted, true);
  assert.equal(S('beatles yesterday', c).accepted, true);
  assert.equal(S('yesterday', c).accepted, true);
});

test('rechaza artista incorrecto y coincidencias irrelevantes', () => {
  const cover = { title: 'Yesterday', artist: 'Cover Band' };
  assert.equal(S('Yesterday The Beatles', cover).accepted, false);
  assert.equal(S('Yesterday The Beatles', { title: 'Yesterday Once More', artist: 'Carpenters' }).accepted, false);
  assert.equal(S('Hey Jude Beatles', { title: 'Yesterday', artist: 'The Beatles' }).accepted, false);
  assert.equal(S('zzzz qqqq', { title: 'Yesterday', artist: 'The Beatles' }).accepted, false);
});

test('restricciones explícitas title/artist son estrictas', () => {
  const c = { title: 'Yesterday', artist: 'Cover Band' };
  assert.equal(S('yesterday', c, { artist: 'The Beatles' }).accepted, false);
  assert.equal(S('yesterday', { title: 'Yesterday', artist: 'The Beatles' }, { artist: 'Beatles' }).accepted, true);
});

test('versiones no pedidas puntúan menos; si se piden, no se penalizan', () => {
  const studio = { title: 'Yesterday', artist: 'The Beatles' };
  const live = { title: 'Yesterday (Live)', artist: 'The Beatles' };
  assert.ok(S('Yesterday Beatles', studio).score > S('Yesterday Beatles', live).score);
  assert.ok(Math.abs(S('Yesterday Beatles live', live).score - S('Yesterday Beatles live', studio).score) < 0.25);
  assert.ok(S('Yesterday Beatles live', live).score >= 0.9);
});

test('agrupa duplicados por título/artista/versión/duración y separa versiones', () => {
  const mk = (title, artist, duration, ref) => ({ c: { title, artist, duration, ref }, score: 1 });
  const groups = groupCandidates([
    mk('Yesterday', 'The Beatles', 125, 'a'), mk('Yesterday (Remastered)', 'Beatles', 126, 'b'),
    mk('Yesterday (Live)', 'The Beatles', 130, 'c'), mk('Yesterday', 'The Beatles', 260, 'd'),
  ]);
  const refs = groups.map((g) => g.map((m) => m.c.ref).sort().join(''));
  assert.deepEqual(refs.sort(), ['ab', 'c', 'd']);
});

test('selección por nivel: LOSSLESS prioriza profundidad, luego frecuencia; sin pérdida nunca gana a lossless', () => {
  const L = (bd, sr, flags = {}) => ({ info: { lossless: true, codec: 'flac', bitDepth: bd, sampleRate: sr }, flags, id: `${bd}/${sr}` });
  const M = (br) => ({ info: { lossless: false, codec: 'mp3', bitrate: br }, flags: {}, id: `mp3-${br}` });
  assert.equal(pickBest([L(16, 192000), L(24, 44100), M(320000)], 'LOSSLESS').id, '24/44100');
  assert.equal(pickBest([L(24, 48000), L(24, 96000)], 'LOSSLESS').id, '24/96000');
  assert.equal(pickBest([L(24, 96000, { suspectTranscode: true }), L(16, 44100)], 'LOSSLESS').id, '16/44100');
  assert.equal(pickBest([M(320000), L(16, 44100)], 'LOSSLESS').id, '16/44100');
  assert.equal(pickBest([L(16, 44100, { suspectTranscode: true }), M(128000)], 'LOSSLESS').id, 'mp3-128000'); // FLAC derivado de MP3 < MP3 honesto
  assert.equal(pickBest([L(16, 44100, { suspectTranscode: true })], 'LOSSLESS').id, '16/44100'); // si es lo único, se sirve con aviso
  assert.equal(pickBest([M(128000)], 'LOSSLESS').id, 'mp3-128000'); // si solo hay lossy, se devuelve etiquetado como lossy
  assert.equal(pickBest([L(16, 44100), M(256000), M(128000)], 'HIGH').id, 'mp3-256000');
  assert.equal(pickBest([L(16, 44100), M(256000), M(128000)], 'LOW').id, 'mp3-128000');
  assert.equal(pickBest([], 'LOSSLESS'), null);
  assert.equal(normalizeTier('lossless'), 'LOSSLESS'); assert.equal(normalizeTier('High'), 'HIGH'); assert.equal(normalizeTier('LOW'), 'LOW');
});

test('ids: ida y vuelta, y rechazo de ids manipulados', () => {
  const refs = [['ia', 'item', 'stem'], ['jm', '12']];
  assert.deepEqual(decodeRefs(encodeRefs(refs), ['ia', 'jm']), refs);
  assert.equal(decodeRefs('%%%', ['ia']), null);
  assert.equal(decodeRefs(encodeRefs([['xx', 'a']]), ['ia']), null);
  assert.equal(decodeRefs(Buffer.from('{"a":1}').toString('base64url'), ['ia']), null);
});
